//从PSD角色文件导出成角色立绘的PNG系列图
//by VariableD

//使用方法为：
//(1)打开要导出的PSD文件，之后点击文件->脚本->浏览
//(2)选择要导出到的文件夹
//(3)会按照“PSD文件名_服装名_表情名”的格式，导出成PNG

//PSD文件的格式：
//(1)至少要有一个不属于任何图层组的图层，作为固定显示的素体
//(2)至少要有两个图层组，其中一个包含所有的服装差分，另外一个包含所有的表情差分
//(3)所有不属于任何图层组的图层，将会当做固定的部件（例如眼镜）
//(4)除了服装、表情（从下往上数的第一、二个图层组）以外，其他的图层组会被无视，不参与导出
//(5)如果没有服装差分的话，服装的图层组里可以放张透明的图层……


//定义全局变数
var destinationFolder; //目标文件夹

var sourcePsd; //原PSD
var duppedPsd; //复制出的新PSD

//判断是否存在文件和导出目录

main();

// main entry point
function main()
{
	// got a valid document?
	if( app.documents.length <= 0 )
	{
		if(app.playbackDisplayDialogs != DialogModes.NO)
		{
			alert("至少需要打开一个文件哦！");
		}
		// quit, returning 'cancel' makes the actions palette not record our script
    	return 'cancel';
    }

	// ask for where the exported files should go
	destinationFolder = Folder.selectDialog("请选择导出目录：");
	if(!destinationFolder)
	{
		return;
	}


	// cache useful variables
	sourcePsdName = app.activeDocument.name; //取得当前文件名
	var layerCount = app.documents[sourcePsdName].layers.length; //取得图层总数
	var layerSetsCount = app.documents[sourcePsdName].layerSets.length; //取得图层组总数
	
	//alert("共有"+layerCount+"个图层，"+layerSetsCount+"个图层组");
	
	//判断文件内容是否符合导出需求
	if((layerCount == 0)&&(layerSetsCount <= 1))
	{
		if(app.playbackDisplayDialogs != DialogModes.NO)
		{
			alert("至少要有1个固定图层（素体）和2个图层组（服装、表情）的说。");
			// quit, returning 'cancel' makes the actions palette not record our script
			return 'cancel';
		}
	}
	
	// 复制这个PSD，这样我们就可以不动原文件，随便搞它了
	duppedPsd = app.activeDocument.duplicate();
	duppedPsd.activeLayer = duppedPsd.layers[duppedPsd.layers.length-1]; //将底层作为activelayer
	
	//先隐藏所有的图层和图层组
	hideAllArtLayers(duppedPsd);
	
	//将没有在组内的图层都显示出来（素体、头发等）
	showAllArtLayers(duppedPsd);
	
	//循环输出图层组的排列组合

	//服装（从下往上数，第二个图层组）
	var clothGroup = duppedPsd.layerSets[duppedPsd.layerSets.length-2];
	//表情（从下往上数，第一个图层组）
	var emoGroup = duppedPsd.layerSets[duppedPsd.layerSets.length-1];
	
	for (var i=0; i<clothGroup.artLayers.length;i++)
	{
		//显示衣服
		clothGroup.artLayers[i].visible=true;
		
		//导出表情
		for (var j=0 ; j<emoGroup.artLayers.length;j++)
		{
			emoGroup.artLayers[j].visible=true;
			exportAndSave(duppedPsd,sourcePsdName.replace(/\.[^\.]+$/, '')+"_"+clothGroup.artLayers[i].name+"_"+emoGroup.artLayers[j].name);
			emoGroup.artLayers[j].visible=false;
		}
		
		//隐藏衣服
		clothGroup.artLayers[i].visible=false;
		
	}
	
	//处理完毕后，关闭复制的PSD
	duppedPsd.close(SaveOptions.DONOTSAVECHANGES);
	
	
}

//隐藏所有图层、图层组

function hideAllArtLayers(obj)
{
	for(var i = 0; i < obj.artLayers.length; i++)
	{
		obj.artLayers[i].allLocked = false;
		obj.artLayers[i].visible = false;
	}

	for( var i = 0; i < obj.layerSets.length; i++)
	{
		hideAllArtLayers(obj.layerSets[i]);
	}
}

//显示所有图层
function showAllArtLayers(obj)
{
	for(var i = 0; i < obj.artLayers.length; i++)
	{
		obj.artLayers[i].visible = true;
	}
}



//导出并保存图片
function exportAndSave(psd, fileName)
{
    // save the image
    fileName = fileName.replace(/\*/g, "_");
	var pngFile = new File(destinationFolder + "/" + fileName + ".png");
	var pngSaveOptions = new PNGSaveOptions();
	psd.saveAs(pngFile, pngSaveOptions, true, Extension.LOWERCASE);	
}

	
	
